package com.stackroute.gipherrecommendersystem.exception;

public class GiphNotFoundException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public GiphNotFoundException(String message) {
		super(message);
	}

}
