package com.stackroute.gipherrecommendersystem;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest
public class GipherRecommenderSystemApplicationTests {

	@Test
	public void contextLoads() {
	}

}

